import pygame
import random
import sys
import os

# --- Pygame Başlatma ---
pygame.init()

# --- Temel Ayarlar ve Sabitler ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 400
GROUND_HEIGHT = 350
FPS = 60

# Renkler
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Ekran ve Saat (FPS)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Çöp Adam & Kaktüs Oyunu")
clock = pygame.time.Clock()

# --- Görsel Yükleme ---
current_dir = os.path.dirname(__file__)

try:
    # Çöp Adam
    player_image_path = os.path.join(current_dir, 'stickman.png')
    player_image = pygame.image.load(player_image_path).convert_alpha()
    player_width = 40
    player_height = 60
    player_image = pygame.transform.scale(player_image, (player_width, player_height))

    # Kaktüs
    cactus_image_path = os.path.join(current_dir, 'cactus.png')
    cactus_image = pygame.image.load(cactus_image_path).convert_alpha()
    obstacle_width = 30
    obstacle_height = 50
    cactus_image = pygame.transform.scale(cactus_image, (obstacle_width, obstacle_height))
    
    # Elma (YENİ)
    apple_image_path = os.path.join(current_dir, 'apple.png')
    apple_image = pygame.image.load(apple_image_path).convert_alpha()
    apple_width = 30
    apple_height = 30
    apple_image = pygame.transform.scale(apple_image, (apple_width, apple_height))

except pygame.error as e:
    print(f"Hata: Görsel yüklenemedi: {e}")
    # (YENİ) Hata mesajını güncelledim
    print("Lütfen 'stickman.png', 'cactus.png' ve 'apple.png' dosyalarının Python dosyanızla aynı klasörde olduğundan emin olun.")
    pygame.quit()
    sys.exit()

# --- Oyuncu Ayarları ---
player_x = 50
player_y = GROUND_HEIGHT - player_height
player_y_velocity = 0
gravity = 1
jump_strength = -18
is_jumping = False
player_rect = pygame.Rect(player_x, player_y, player_width, player_height)

# --- Engel Ayarları ---
obstacle_speed = 7
obstacle_list = []
SPAWN_OBSTACLE = pygame.USEREVENT
# (DEĞİŞTİ) Artık sabit 1500ms değil, rastgele bir süreyle başlıyor
pygame.time.set_timer(SPAWN_OBSTACLE, random.randint(1200, 2500)) 

# --- Elma Ayarları (YENİ) ---
apple_list = []
bonus_score = 50 # Elma skoru
SPAWN_APPLE = pygame.USEREVENT + 1 # Farklı bir event ID'si
pygame.time.set_timer(SPAWN_APPLE, random.randint(5000, 10000)) # Elmalar daha nadir çıksın

# --- Oyun Değişkenleri ---
game_over = False
score = 0
font = pygame.font.SysFont('Arial', 30)

def draw_game():
    """Tüm oyun elemanlarını ekrana çizer."""
    screen.fill(WHITE)
    pygame.draw.line(screen, BLACK, (0, GROUND_HEIGHT), (SCREEN_WIDTH, GROUND_HEIGHT), 2)
    
    # Oyuncu
    screen.blit(player_image, player_rect)
    
    # Engeller
    for obstacle in obstacle_list:
        screen.blit(cactus_image, obstacle)
        
    # Elmalar (YENİ)
    for apple in apple_list:
        screen.blit(apple_image, apple)
        
    # Skor
    score_text = font.render(f"Skor: {score}", True, BLACK)
    screen.blit(score_text, (10, 10))
    
    if game_over:
        game_over_text = font.render("Oyun Bitti! (R = Yeniden Başla)", True, RED)
        text_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        screen.blit(game_over_text, text_rect)

    pygame.display.flip()

def reset_game():
    """Oyunu başlangıç durumuna sıfırlar."""
    global player_y, player_y_velocity, is_jumping, obstacle_list, apple_list, score, game_over
    
    player_y = GROUND_HEIGHT - player_height
    player_rect.y = player_y
    player_y_velocity = 0
    is_jumping = False
    obstacle_list = []
    apple_list = [] # (YENİ) Elmaları sıfırla
    score = 0
    game_over = False
    
    # (DEĞİŞTİ) Zamanlayıcıları rastgele olarak yeniden başlat
    pygame.time.set_timer(SPAWN_OBSTACLE, random.randint(1200, 2500))
    pygame.time.set_timer(SPAWN_APPLE, random.randint(5000, 10000)) # (YENİ)

# --- Ana Oyun Döngüsü ---
running = True
while running:
    clock.tick(FPS)
    
    # --- 1. Olayları (Input) Kontrol Et ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()
            
        if event.type == pygame.KEYDOWN:
            if not game_over:
                if (event.key == pygame.K_SPACE or event.key == pygame.K_w) and not is_jumping:
                    player_y_velocity = jump_strength
                    is_jumping = True
            
            if game_over and event.key == pygame.K_r:
                reset_game()
                
        # (DEĞİŞTİ) Kaktüs oluşturma olayı
        if event.type == SPAWN_OBSTACLE and not game_over:
            new_obstacle = pygame.Rect(SCREEN_WIDTH, 
                                       GROUND_HEIGHT - obstacle_height, 
                                       obstacle_width, 
                                       obstacle_height)
            obstacle_list.append(new_obstacle)
            
            # (YENİ) Bir sonraki kaktüs için YENİ ve RASTGELE bir zamanlayıcı ayarla
            # Bu, "çok yakın olmamasını" (min 1200ms) ve sıklığın rastgele olmasını sağlar
            next_obstacle_delay = random.randint(1200, 2500)
            pygame.time.set_timer(SPAWN_OBSTACLE, next_obstacle_delay)

        # (YENİ) Elma oluşturma olayı
        if event.type == SPAWN_APPLE and not game_over:
            # Elma havada, zıplayarak alınabilecek bir yükseklikte olsun
            apple_y = random.randint(GROUND_HEIGHT - 150, GROUND_HEIGHT - 80)
            new_apple = pygame.Rect(SCREEN_WIDTH, apple_y, apple_width, apple_height)
            apple_list.append(new_apple)
            
            # (YENİ) Bir sonraki elma için rastgele zamanlayıcı ayarla
            next_apple_delay = random.randint(5000, 10000)
            pygame.time.set_timer(SPAWN_APPLE, next_apple_delay)

    # --- 2. Oyun Mantığını Güncelle ---
    if not game_over:
        # --- Oyuncu Mantığı ---
        player_y_velocity += gravity
        player_rect.y += player_y_velocity
        
        if player_rect.y >= GROUND_HEIGHT - player_height:
            player_rect.y = GROUND_HEIGHT - player_height
            player_y_velocity = 0
            is_jumping = False
            
        # --- Engel Mantığı ---
        temp_obstacle_list = []
        for obstacle in obstacle_list:
            obstacle.x -= obstacle_speed
            
            if obstacle.x > -obstacle_width:
                temp_obstacle_list.append(obstacle)
            else:
                score += 1 # Kaktüsü atlayınca 1 puan
                
        obstacle_list = temp_obstacle_list

        # --- Elma Mantığı (YENİ) ---
        temp_apple_list = []
        for apple in apple_list:
            apple.x -= obstacle_speed # Elmalar da kaktüsle aynı hızda hareket etsin
            
            # Elma ile çarpışma tespiti
            if player_rect.colliderect(apple):
                score += bonus_score # Bonus skoru ekle
                # Çarpışan elmayı listeye geri ekleme (toplanmış olur)
            elif apple.x > -apple_width:
                temp_apple_list.append(apple) # Ekranda kalan elmaları koru
        
        apple_list = temp_apple_list

        # --- Çarpışma Kontrolü (Kaktüs) ---
        for obstacle in obstacle_list:
            if player_rect.colliderect(obstacle):
                game_over = True
                pygame.time.set_timer(SPAWN_OBSTACLE, 0) # Kaktüs üretimini durdur
                pygame.time.set_timer(SPAWN_APPLE, 0) # (YENİ) Elma üretimini durdur

    # --- 3. Ekrana Çizdir ---
    draw_game()
